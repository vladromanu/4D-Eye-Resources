﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.TestHost;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Serilog;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;
using WebBeds.API.Starter.Api;

namespace WebBeds.API.Starter.Tests.FakeData
{
    [ExcludeFromCodeCoverage]
    public static class FakeHost
    {
        private static IHost _host;

        private static async Task<IHost> GetHostAsync()
        {
            if (_host is null)
            {
                // Arrange
                var hostBuilder = new HostBuilder()
                    .ConfigureWebHost(webHost =>
                    {
                        // Add TestServer
                        webHost.UseTestServer();

                        // Specify the environment
                        webHost.UseEnvironment("Test");

                        webHost.UseStartup<Startup>();

                        // configure the services after the startup has been called.
                        webHost.ConfigureTestServices(services =>
                        {
                            // register the test one specifically (mock/stub out the dependency)
                            //services.AddTransient<IUserRepository, FakeUserRepository>();
                        });

                        var configPath = Path.Combine(Directory.GetCurrentDirectory(), "appsettings.json");

                        webHost.ConfigureAppConfiguration((context, conf) =>
                        {
                            conf.AddJsonFile(configPath);
                        });

                        webHost.UseSerilog();
                    });

                _host = await hostBuilder.StartAsync();
            }

            return _host;
        }

        public static async Task<HttpClient> GetClientAsync()
        {
            var host = await GetHostAsync();

            // Create an HttpClient which is setup for the test host
            return host.GetTestClient();
        }
    }
}
