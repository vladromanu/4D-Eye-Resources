﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using WebBeds.API.Starter.Tests.FakeData;
using Xunit;

namespace WebBeds.API.Starter.Tests.Integration
{
    public class UserResourceTests
    {
        #region Fields
        #endregion

        [Fact]
        [Trait("Integration", "Roomtype")]
        public async Task GetCollection_ReturnsOK()
        {
            // Arrange
            var client = await FakeHost.GetClientAsync();

            // Act
            var response = await client.GetAsync("/api/user");

            response.EnsureSuccessStatusCode();

            // Assert
            Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        }
    }
}
