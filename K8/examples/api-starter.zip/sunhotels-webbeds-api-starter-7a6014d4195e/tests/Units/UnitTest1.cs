using System;
using Xunit;

namespace WebBeds.API.Starter.Tests.Units
{
    public class Unit
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
