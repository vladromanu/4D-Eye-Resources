﻿using WebBeds.API.Starter.Domain.UserAggregate;

namespace WebBeds.API.Starter.Infrastructure
{
    public interface IUserRepository : IRepository<User>
    {
    }
}
