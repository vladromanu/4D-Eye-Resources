﻿using System.Collections.Generic;
using System.Threading.Tasks;
using WebBeds.API.Starter.Domain;

namespace WebBeds.API.Starter.Infrastructure
{
    public interface IRepository<TEntity> where TEntity : IAggregateRoot
    {
        Task<IEnumerable<TEntity>> FindAsync();

        Task<TEntity> FindOneAsync(int id);
    }
}
