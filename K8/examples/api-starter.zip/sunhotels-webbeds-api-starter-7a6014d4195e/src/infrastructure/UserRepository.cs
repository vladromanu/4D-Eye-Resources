﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using WebBeds.API.Starter.Domain.UserAggregate;

namespace WebBeds.API.Starter.Infrastructure
{
    public class UserRepository : IUserRepository
    {
        public async Task<IEnumerable<User>> FindAsync()
        {
            // Replace the following code to use a DB Connection or HTTP Client
            await Task.Delay(TimeSpan.FromSeconds(1)).ConfigureAwait(false);

            throw new NotImplementedException();
        }

        public async Task<User> FindOneAsync(int id)
        {
            // Replace the following code to use a DB Connection or HTTP Client
            await Task.Delay(TimeSpan.FromSeconds(1)).ConfigureAwait(false);
            
            throw new NotImplementedException();
        }
    }
}
