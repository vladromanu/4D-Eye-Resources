﻿using Microsoft.AspNetCore.Http;
using Serilog.Events;
using System;

namespace WebBeds.API.Starter.Api.Helper
{
    public static class LogHelper
    {
        /// <summary>
        /// Identify K8s healthcheck endpoints
        /// </summary>
        /// <param name="ctx"></param>
        /// <returns></returns>
        private static bool IsHealthCheckEndpoint(HttpContext ctx)
        {
            var endpoint = ctx.GetEndpoint();

            if (endpoint is object) // same as !(endpoint is null)
            {
                return string.Equals(endpoint.DisplayName,
                                    "Health checks", // Default Health check name
                                    StringComparison.Ordinal);
            }

            // No endpoint, so not a health check endpoint
            return false;
        }

        /// <summary>
        /// LogLevel according to endpoint type
        /// </summary>
        /// <param name="ctx"></param>
        /// <param name="_"></param>
        /// <param name="ex"></param>
        /// <returns></returns>
        public static LogEventLevel ExcludeHealthChecks(HttpContext ctx, double _, Exception ex)
        {
            if (ctx is null)
            {
                throw new ArgumentNullException(nameof(ctx));
            }

            if (!(ex is null))
            {
                return LogEventLevel.Error;
            }

            if (ctx.Response.StatusCode > 499) // 499 = CLIENT CLOSED REQUEST
            {
                return LogEventLevel.Error;
            }

            if (IsHealthCheckEndpoint(ctx)) // Not an error, check if it was a health check
            {
                return LogEventLevel.Verbose; // Was a health check, use Verbose
            }

            return LogEventLevel.Information;
        }
    }
}
