﻿#pragma warning disable CA1303 // Do not pass literals as localized parameters

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using WebBeds.API.Starter.Application.Users;
using WebBeds.API.Starter.Domain;
using WebBeds.API.Starter.Domain.UserAggregate;

namespace WebBeds.API.Starter.Api.Controllers
{
    /// <summary>
    /// 
    /// </summary>
    [Route(Constants.UsersRoute)]
    [Produces("application/json")]
    [ApiController]
    public class UserController : ControllerBase
    {
        #region Fields
        /// <summary>
        /// 
        /// </summary>
        private static readonly string[] Summaries = new[]
        {
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };

        /// <summary>
        /// 
        /// </summary>
        private static readonly string[] Names = new[]
        {
            "Eugen", "Alexandra", "Costel", "Vlad", "Popescu", "Toma"
        };

        /// <summary>
        /// 
        /// </summary>
        private readonly ILogger<UserController> _logger;
        #endregion

        #region Startup
        /// <summary>
        /// 
        /// </summary>
        /// <param name="logger"></param>
        public UserController(ILogger<UserController> logger)
        {
            _logger = logger;
        }
        #endregion

        /// <summary>
        /// GET: api/user
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<IEnumerable<UserDto>>> Get()
        {
            _logger.LogInformation("Getting the user collection");

            // Replace the following code to use a Service
            var rnd = new Random();

            var list = Enumerable.Range(1, 5).Select(index => new UserDto()
            {
                FullName = $"{Names[rnd.Next(Names.Length)]} {Names[rnd.Next(Names.Length)]}",
                Address = new Address()
                {
                    Street = "Anastasie Panu",
                    StreetNo = 27
                },
                CreatedAt = DateTime.Now.AddDays(index),
                Summary = Summaries[rnd.Next(Summaries.Length)]
            });

            await Task.Delay(TimeSpan.FromSeconds(1)).ConfigureAwait(false);

            return Ok(list);
        }
    }
}
