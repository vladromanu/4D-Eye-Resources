#pragma warning disable CA1822 // Mark members as static
#pragma warning disable CA1303 // Do not pass literals as localized parameters

using System;
using System.IO;
using System.Reflection;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json.Serialization;
using Prometheus;
using Serilog;

using WebBeds.API.Starter.Api.Config;
using WebBeds.API.Starter.Api.Extensions;
using WebBeds.API.Starter.Api.Helper;

namespace WebBeds.API.Starter.Api
{
    /// <summary>
    /// Startup
    /// </summary>
    public class Startup
    {
        #region Properties
        /// <summary>
        /// Configuration
        /// </summary>
        public IConfiguration Configuration { get; }
        #endregion

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="configuration"></param>
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="services"></param>
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers()
                .AddJsonOptions(options =>
                {
                    options.JsonSerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
                });

            services.AddHealthChecks();

            services.AddHttpClient(); // Register IHttpClientFactory

            services.AddResponseCompression(); // Enable compression

            // Register services & repositories
            services.AddConfig(Configuration)
                    .AddServices()
                    .AddRepositories();

            // Register the Swagger generator, defining 1 or more Swagger documents
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo
                {
                    Version = "v1",
                    Title = "WebBeds-API-Starter API",
                    Description = "A starter API template for WebBeds",
                    TermsOfService = new Uri(Configuration["TermsUrl"]),
                    Contact = new OpenApiContact
                    {
                        Name = "Fernando Arias",
                        Email = string.Empty,
                        Url = new Uri(Configuration["TwitterUrl"]),
                    },
                    License = new OpenApiLicense
                    {
                        Name = "Use under LICX",
                        Url = new Uri(Configuration["LicenceUrl"]),
                    }
                });

                // Set the comments path for the Swagger JSON and UI.
                var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
                var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);

                c.IncludeXmlComments(xmlPath);
            });
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="app"></param>
        /// <param name="env"></param>
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseSwagger(c =>
            {
                c.RouteTemplate = string.Concat(Configuration["AuthProxyPath"], "/swagger/{documentName}/swagger.json");
            });

            app.UseHttpsRedirection();

            // Write streamlined request completion events, instead of the more verbose ones from the framework.
            // To use the default framework request logging instead, remove this line and set the "Microsoft"
            // level in appsettings.json to "Information".
            app.UseSerilogRequestLogging(opts =>
            {
                opts.GetLevel = LogHelper.ExcludeHealthChecks; // Use the custom level
            });

            // Enable middleware to serve swagger-ui (HTML, JS, CSS, etc.),
            // specifying the Swagger JSON endpoint.
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint($"/{Configuration["AuthProxyPath"]}/swagger/v1/swagger.json", "WebBeds API Starter V1");
                c.RoutePrefix = $"{Configuration["AuthProxyPath"]}/swagger";
            });

            app.UseRouting();
            app.UseHttpMetrics(PrometheusConfig.Options);
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
                endpoints.MapMetrics();

                HealthCheckOptions healthOptions = new HealthCheckOptions()
                {
                    AllowCachingResponses = true,
                    ResponseWriter = WriteReadinessResponse
                };

                endpoints.MapHealthChecks("/Ready", healthOptions);
                endpoints.MapHealthChecks("/Live", healthOptions);
            });
        }

        /// <summary>
        /// Used tp populate the Healthcheck responses
        /// </summary>
        /// <param name="context"></param>
        /// <param name="result"></param>
        /// <returns></returns>
        private static Task WriteReadinessResponse(HttpContext context, HealthReport result)
        {
            string isSuccess = "true";

            context.Response.ContentType = "application/json";
            context.Response.StatusCode = StatusCodes.Status200OK;

            return context.Response.WriteAsync(isSuccess, Encoding.UTF8);
        }
    }
}
