﻿using System;
using WebBeds.API.Starter.Domain.UserAggregate;

namespace WebBeds.API.Starter.Application.Users
{
    public class UserDto
    {
        #region Properties
        public string FullName { get; set; }

        public Address Address { get; set; }

        public DateTime CreatedAt { get; set; }

        public string Summary { get; set; }
        #endregion
        
    }
}
