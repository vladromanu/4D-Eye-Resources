﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace WebBeds.API.Starter.Application.Users
{
    public interface IUserService
    {
        Task<IEnumerable<UserDto>> GetAllAsync();

        Task<UserDto> GetAsync(int id);
    }
}
