﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using WebBeds.API.Starter.Infrastructure;

namespace WebBeds.API.Starter.Application.Users
{
    public class UserService : IUserService
    {
        #region Fields
        private readonly ILogger<UserService> _logger;
        private readonly IUserRepository _userRepository;
        #endregion

        public UserService(IUserRepository userRepository, ILogger<UserService> logger)
        {
            _userRepository = userRepository ?? throw new ArgumentNullException(nameof(userRepository));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public async Task<IEnumerable<UserDto>> GetAllAsync()
        {
            // Replace the following code to use a DB Connection or HTTP Client
            await Task.Delay(TimeSpan.FromSeconds(1)).ConfigureAwait(false);

            throw new NotImplementedException();
        }

        public async Task<UserDto> GetAsync(int id)
        {
            // Replace the following code to use a DB Connection or HTTP Client
            await Task.Delay(TimeSpan.FromSeconds(1)).ConfigureAwait(false);

            throw new NotImplementedException();
        }
    }
}
