﻿namespace WebBeds.API.Starter.Domain
{
    public static class DefaultMediaTypes
    {
        public static readonly string ProtoBuf = "application/x-protobuf";
        public static readonly string MessagePack = "application/x-msgpack";
        public static readonly string Json = "application/json";
        public static readonly string Xml = "application/xml";
        public static readonly string Form = "application/x-www-form-urlencoded";
        public static readonly string Unknown = "application/octet-stream";
    }
}
