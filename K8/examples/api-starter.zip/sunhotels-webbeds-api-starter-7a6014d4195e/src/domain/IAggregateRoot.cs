﻿namespace WebBeds.API.Starter.Domain
{
    public interface IAggregateRoot
    {
    }
}
