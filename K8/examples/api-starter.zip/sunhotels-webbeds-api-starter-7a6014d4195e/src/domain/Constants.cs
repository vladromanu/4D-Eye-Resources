﻿namespace WebBeds.API.Starter.Domain
{
    public static class Constants
    {
        #region Api Urls
        public const string UsersRoute = "api/user";
        #endregion
    }
}
