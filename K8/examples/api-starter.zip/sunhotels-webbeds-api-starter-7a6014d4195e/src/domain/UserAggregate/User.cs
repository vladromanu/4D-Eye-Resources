using System;

namespace WebBeds.API.Starter.Domain.UserAggregate
{
    public class User : IAggregateRoot
    {
        #region Properties
        public string FirstName { get; set; }

        public string LastName { get; set; }

        public Address Address { get; set; }

        public DateTime CreatedAt { get; set; }

        public string Summary { get; set; }
        #endregion
    }
}
