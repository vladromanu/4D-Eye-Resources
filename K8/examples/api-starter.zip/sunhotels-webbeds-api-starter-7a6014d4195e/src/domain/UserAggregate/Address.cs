﻿namespace WebBeds.API.Starter.Domain.UserAggregate
{
    public class Address
    {
        #region Properties
        public string Street { get; set; }

        public int StreetNo { get; set; }
        #endregion
    }
}
