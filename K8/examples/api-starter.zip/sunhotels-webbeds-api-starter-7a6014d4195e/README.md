## Install the new template ##

Once you cloned this repository, you'll have to make the template available into `dotnet new` command. Please follow the below steps:

1. Open a new terminal and change the directory to cloned repository:
`C:\WEBBEDS\webbeds-api-starter`
2. Run `dotnet new -i .` to add the current template to list.
3. Install the new template by provind the output directory, the namespace & application name: 
`dotnet new webbeds-api --appName "roomtype-content" --namespace "WebBeds.Roomtype.Content" -o ..\webbeds-roomtype-content\` 
4. Find the element *DockerfileFile* within `*.Api.csproj` layer and remove the *dev* extension.

## Optional settings ##
- Replace `localhost` with a new DNS/IP:
    1. Open `applicationhost.config`
    2. Add the following tags:
	
    	*HTTP:*
    ```
    <binding protocol="http" bindingInformation="*:7370:localhost" />
    <binding protocol="http" bindingInformation="*:7370:192.168.1.4" /> 
    <binding protocol="http" bindingInformation="*:7370:webbeds.local" />
    ```
		
		*HTTPS:*
    ```
    <binding protocol="https" bindingInformation="*:44370:localhost" />
    <binding protocol="https" bindingInformation="*:44370:192.168.1.4" /> 
    <binding protocol="https" bindingInformation="*:44370:webbeds.local" />
    ```
	
    
	3. Add DNS to hosts file: `192.168.1.4 webbeds.local`
	
- More to come...

## Troubleshooting ##
- Missing shared drivers for Docker: 
    * https://docs.microsoft.com/en-us/visualstudio/containers/troubleshooting-docker-errors?view=vs-2019
    * https://stackoverflow.com/questions/59942110/docker-drive-has-not-been-shared
- Disable Hyper-V Windows feature: 
    * https://stackoverflow.com/questions/47103570/asp-net-core-2-0-multiple-projects-solution-docker-file
- Get VSDBGPS: 
    * https://github.com/microsoft/DockerTools/issues/226#issuecomment-582169213
